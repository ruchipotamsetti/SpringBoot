package com.example.purchaseservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.purchaseservice.model.Product;

@RestController
@RequestMapping("purchase")
public class PurchaseController {
	
	@Autowired
	RestTemplate restTemplate;

	@GetMapping("dispprods")
	public ResponseEntity<List<Product>> displayProds(){
		List<Product> products = restTemplate.getForObject("http://product/products/getprods", List.class);
		//List<Product> products = restTemplate.getForObject("http://172.27.8.144/products/getprods", List.class);
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
	
	@PostMapping
	public ResponseEntity<Product> addProduct(@RequestBody Product product){
		restTemplate.postForObject("http://product/products/addprod", product, Product.class);
		return new ResponseEntity<Product>(product, HttpStatus.OK);
		
	}
	
	@GetMapping("getportinfo")
	public ResponseEntity<String> getPortInfo(){
		String portMsg= restTemplate.getForObject("http://product/products/getport", String.class);
		//List<Product> products = restTemplate.getForObject("http://172.27.8.144/products/getprods", List.class);
		return new ResponseEntity<String>(portMsg, HttpStatus.OK);
	}
	
}
