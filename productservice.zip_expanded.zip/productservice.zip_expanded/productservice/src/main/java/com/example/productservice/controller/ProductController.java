package com.example.productservice.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.productservice.model.Product;

@RestController
@RequestMapping("products")
public class ProductController {

	List<Product>products;
	
	@Value("${server.port}")
	int port;
	
	@PostConstruct
	void init() {
		
		products = new ArrayList<>();
		
		List<Product>prods =  Arrays.asList(new Product(1, "hp laptop", 60000), 
				new Product(2, "dell laptop", 50000),
				new Product(3, "lenovo laptop", 55000)
				);
		
		products.addAll(prods);
	}
	
	@GetMapping("getprods")
	public ResponseEntity<List<Product>> getAllProd(){
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		
	}
	
	@PostMapping("addprod")
	public ResponseEntity<Product> addProduct(@RequestBody Product product){
		
		products.add(product);
		return new ResponseEntity<Product>(product, HttpStatus.OK);
		
	}
	
	@GetMapping("getport")
	public ResponseEntity<String> getPort(){
		
		String portMsg = "the prodict port is "+port;
		return new ResponseEntity<String>(portMsg, HttpStatus.OK);
		
	}
	
	
	
	
}
